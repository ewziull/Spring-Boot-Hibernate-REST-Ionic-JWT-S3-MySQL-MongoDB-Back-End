package carreiras.com.github.pedidosbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
